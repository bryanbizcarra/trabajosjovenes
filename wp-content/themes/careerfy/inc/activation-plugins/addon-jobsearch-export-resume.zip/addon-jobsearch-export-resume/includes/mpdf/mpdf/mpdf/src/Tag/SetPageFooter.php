<?php

namespace Mpdf\Tag;

class SetPageFooter extends SetHtmlPageFooter
{


}
